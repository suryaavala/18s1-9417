Copy the data files from `googledrive/data/<mnist/emnist>` here depending on what you are planning to run.
