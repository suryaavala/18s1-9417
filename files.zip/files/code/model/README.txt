Replace this directory with the entire `googledrive/model` directory from googledrive
